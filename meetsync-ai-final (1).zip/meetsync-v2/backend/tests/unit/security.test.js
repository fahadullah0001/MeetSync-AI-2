/**
 * Unit tests — security middleware
 */

const { xssSanitizer, requestSizeGuard } = require('../../src/middleware/security');

function mockReqRes(body = {}, query = {}, headers = {}) {
  const req = { body, query, params: {}, headers: { 'content-length': '100', ...headers }, ip: '127.0.0.1' };
  const res = {
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
  };
  const next = jest.fn();
  return { req, res, next };
}

describe('xssSanitizer', () => {
  it('removes script tags from body strings', () => {
    const { req, res, next } = mockReqRes({ title: '<script>alert("xss")</script>Hello' });
    xssSanitizer(req, res, next);
    expect(req.body.title).not.toContain('<script>');
    expect(req.body.title).toContain('Hello');
    expect(next).toHaveBeenCalled();
  });

  it('removes inline event handlers', () => {
    const { req, res, next } = mockReqRes({ name: 'test onclick=steal()' });
    xssSanitizer(req, res, next);
    expect(req.body.name).not.toMatch(/onclick/i);
    expect(next).toHaveBeenCalled();
  });

  it('removes javascript: URLs', () => {
    const { req, res, next } = mockReqRes({ url: 'javascript:alert(1)' });
    xssSanitizer(req, res, next);
    expect(req.body.url).not.toContain('javascript:');
    expect(next).toHaveBeenCalled();
  });

  it('does not modify safe strings', () => {
    const { req, res, next } = mockReqRes({ title: 'Q3 roadmap planning' });
    xssSanitizer(req, res, next);
    expect(req.body.title).toBe('Q3 roadmap planning');
    expect(next).toHaveBeenCalled();
  });

  it('handles nested objects', () => {
    const { req, res, next } = mockReqRes({ config: { name: '<script>evil()</script>' } });
    xssSanitizer(req, res, next);
    expect(req.body.config.name).not.toContain('<script>');
    expect(next).toHaveBeenCalled();
  });

  it('handles arrays', () => {
    const { req, res, next } = mockReqRes({ tags: ['<script>x</script>', 'safe'] });
    xssSanitizer(req, res, next);
    expect(req.body.tags[0]).not.toContain('<script>');
    expect(req.body.tags[1]).toBe('safe');
    expect(next).toHaveBeenCalled();
  });

  it('passes non-string values unchanged', () => {
    const { req, res, next } = mockReqRes({ count: 42, flag: true, nothing: null });
    xssSanitizer(req, res, next);
    expect(req.body.count).toBe(42);
    expect(req.body.flag).toBe(true);
    expect(req.body.nothing).toBe(null);
    expect(next).toHaveBeenCalled();
  });
});

describe('requestSizeGuard', () => {
  it('allows requests under 10MB', () => {
    const { req, res, next } = mockReqRes({}, {}, { 'content-length': '1000' });
    requestSizeGuard(req, res, next);
    expect(next).toHaveBeenCalled();
    expect(res.status).not.toHaveBeenCalled();
  });

  it('blocks requests over 10MB', () => {
    const bigSize = String(11 * 1024 * 1024);
    const { req, res, next } = mockReqRes({}, {}, { 'content-length': bigSize });
    requestSizeGuard(req, res, next);
    expect(res.status).toHaveBeenCalledWith(413);
    expect(next).not.toHaveBeenCalled();
  });

  it('allows requests with no content-length header', () => {
    const { req, res, next } = mockReqRes({}, {}, {});
    req.headers = {};
    requestSizeGuard(req, res, next);
    expect(next).toHaveBeenCalled();
  });
});
