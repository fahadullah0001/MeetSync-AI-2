/**
 * Unit tests — logger
 * Verifies secrets are never logged
 */

const { log } = require('../../src/utils/logger');

describe('logger', () => {
  let consoleSpy;

  beforeEach(() => {
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('logs info messages without throwing', () => {
    expect(() => log.info('Test message')).not.toThrow();
  });

  it('logs with meta without throwing', () => {
    expect(() => log.info('Test', { user_id: '123', action: 'login' })).not.toThrow();
  });

  it('logs warning messages', () => {
    expect(() => log.warn('Something weird')).not.toThrow();
  });

  it('logs error messages', () => {
    expect(() => log.error('Something broke', { error: 'boom' })).not.toThrow();
  });

  describe('secret sanitization', () => {
    it('redacts password fields in meta', () => {
      process.env.NODE_ENV = 'development';
      log.info('User created', { email: 'test@test.com', password: 'supersecret' });
      const output = consoleSpy.mock.calls.join('');
      expect(output).not.toContain('supersecret');
    });

    it('redacts token fields', () => {
      log.info('Token used', { token: 'abc123secret', user: 'test' });
      const output = consoleSpy.mock.calls.join('');
      expect(output).not.toContain('abc123secret');
    });

    it('redacts api_key fields', () => {
      log.info('API call', { api_key: 'sk-ant-secret123' });
      const output = consoleSpy.mock.calls.join('');
      expect(output).not.toContain('sk-ant-secret123');
    });

    it('preserves non-sensitive fields', () => {
      log.info('Event', { user_id: 'uuid-123', action: 'upload' });
      const output = consoleSpy.mock.calls.join('');
      expect(output).toContain('uuid-123');
      expect(output).toContain('upload');
    });
  });
});
