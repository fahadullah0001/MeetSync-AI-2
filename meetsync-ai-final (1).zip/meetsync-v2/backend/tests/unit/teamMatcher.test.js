/**
 * Unit tests — teamMatcher service
 * Tests the fuzzy name matching logic for auto-assignment
 */

const { matchTeamMembers } = require('../../src/services/teamMatcher');

const TEAM = [
  { id: '1', name: 'Sara Malik',  email: 'sara@co.com',  slack_user_id: 'U001' },
  { id: '2', name: 'Zaid Khan',   email: 'zaid@co.com',  slack_user_id: 'U002' },
  { id: '3', name: 'Ali Hassan',  email: 'ali@co.com',   slack_user_id: 'U003' },
  { id: '4', name: 'Nida Rehman', email: 'nida@co.com',  slack_user_id: 'U004' },
];

describe('teamMatcher', () => {
  describe('matchTeamMembers', () => {
    it('matches exact full name', () => {
      const tasks = [{ title: 'Do something', assignee_name: 'Sara Malik' }];
      const result = matchTeamMembers(tasks, TEAM);
      expect(result[0].assignee_email).toBe('sara@co.com');
      expect(result[0].assignee_name).toBe('Sara Malik');
    });

    it('matches first name only', () => {
      const tasks = [{ title: 'Do something', assignee_name: 'Sara' }];
      const result = matchTeamMembers(tasks, TEAM);
      expect(result[0].assignee_email).toBe('sara@co.com');
    });

    it('matches case-insensitively', () => {
      const tasks = [{ title: 'Do something', assignee_name: 'ZAID' }];
      const result = matchTeamMembers(tasks, TEAM);
      expect(result[0].assignee_email).toBe('zaid@co.com');
    });

    it('does not assign if confidence too low', () => {
      const tasks = [{ title: 'Do something', assignee_name: 'John Smith' }];
      const result = matchTeamMembers(tasks, TEAM);
      expect(result[0].assignee_email).toBeUndefined();
    });

    it('returns unmodified task if no assignee_name', () => {
      const tasks = [{ title: 'Do something', assignee_name: null }];
      const result = matchTeamMembers(tasks, TEAM);
      expect(result[0].assignee_email).toBeUndefined();
    });

    it('handles empty team array', () => {
      const tasks = [{ title: 'Do something', assignee_name: 'Sara' }];
      const result = matchTeamMembers(tasks, []);
      expect(result[0].assignee_email).toBeUndefined();
    });

    it('processes multiple tasks correctly', () => {
      const tasks = [
        { title: 'Task 1', assignee_name: 'Sara' },
        { title: 'Task 2', assignee_name: 'Zaid' },
        { title: 'Task 3', assignee_name: 'Nobody' },
      ];
      const result = matchTeamMembers(tasks, TEAM);
      expect(result[0].assignee_email).toBe('sara@co.com');
      expect(result[1].assignee_email).toBe('zaid@co.com');
      expect(result[2].assignee_email).toBeUndefined();
    });

    it('attaches slack_user_id when matched', () => {
      const tasks = [{ title: 'Task', assignee_name: 'Ali' }];
      const result = matchTeamMembers(tasks, TEAM);
      expect(result[0].assignee_slack_id).toBe('U003');
    });
  });
});
