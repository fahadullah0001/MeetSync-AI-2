/**
 * Unit tests — export CSV generation
 */

// We test the toCSV logic by importing the module under test
// Since toCSV is not exported, we test via the HTTP endpoint in api tests.
// Here we test adjacent pure functions.

describe('CSV export logic', () => {
  function toCSV(rows, columns) {
    if (rows.length === 0) return columns.join(',') + '\n';
    const header = columns.join(',');
    const body = rows.map(row =>
      columns.map(col => {
        const val = row[col];
        if (val === null || val === undefined) return '';
        const str = String(val);
        return str.includes(',') || str.includes('"') || str.includes('\n')
          ? `"${str.replace(/"/g, '""')}"`
          : str;
      }).join(',')
    );
    return [header, ...body].join('\n');
  }

  it('generates header row for empty data', () => {
    const csv = toCSV([], ['title', 'assignee', 'due_date']);
    expect(csv).toBe('title,assignee,due_date\n');
  });

  it('generates correct rows', () => {
    const csv = toCSV(
      [{ title: 'Fix bug', assignee: 'Sara', due_date: '2026-04-15' }],
      ['title', 'assignee', 'due_date']
    );
    expect(csv).toContain('Fix bug,Sara,2026-04-15');
  });

  it('wraps values with commas in quotes', () => {
    const csv = toCSV(
      [{ title: 'Fix, the, bug', assignee: 'Sara' }],
      ['title', 'assignee']
    );
    expect(csv).toContain('"Fix, the, bug"');
  });

  it('escapes double quotes inside values', () => {
    const csv = toCSV(
      [{ title: 'He said "hello"', assignee: 'Sara' }],
      ['title', 'assignee']
    );
    expect(csv).toContain('"He said ""hello"""');
  });

  it('handles null and undefined values as empty string', () => {
    const csv = toCSV(
      [{ title: null, assignee: undefined }],
      ['title', 'assignee']
    );
    const rows = csv.split('\n');
    expect(rows[1]).toBe(',');
  });

  it('handles multiple rows', () => {
    const data = [
      { name: 'Alice', score: '100' },
      { name: 'Bob',   score: '85'  },
    ];
    const csv = toCSV(data, ['name', 'score']);
    const rows = csv.split('\n');
    expect(rows).toHaveLength(3); // header + 2 rows
    expect(rows[0]).toBe('name,score');
    expect(rows[1]).toBe('Alice,100');
    expect(rows[2]).toBe('Bob,85');
  });
});
