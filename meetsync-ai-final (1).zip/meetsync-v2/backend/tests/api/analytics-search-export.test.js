/**
 * API Integration Tests — Analytics, Search, Export
 */

const request = require('supertest');

const DB_AVAILABLE  = !!process.env.TEST_DATABASE_URL || !!process.env.DATABASE_URL;
const describeIfDB  = DB_AVAILABLE ? describe : describe.skip;

let app, token;

beforeAll(async () => {
  if (!DB_AVAILABLE) return;
  process.env.NODE_ENV    = 'test';
  process.env.JWT_SECRET  = 'test-secret-at-least-32-chars-long!!';

  const { createApp } = require('../../src/testApp');
  app = createApp();

  const unique = Date.now() + 10;
  const res = await request(app).post('/api/auth/register').send({
    name: 'Analytics Tester',
    email: `analytics${unique}@example.com`,
    password: 'password123',
    workspaceName: `Analytics WS ${unique}`,
  });
  token = res.body.accessToken;
});

// ── Analytics ─────────────────────────────────────────────────────────────
describeIfDB('GET /api/analytics/*', () => {
  const endpoints = [
    '/api/analytics/overview',
    '/api/analytics/tasks-by-status',
    '/api/analytics/tasks-by-assignee',
    '/api/analytics/meetings-over-time',
    '/api/analytics/completion-trend',
    '/api/analytics/priority-breakdown',
    '/api/analytics/integration-usage',
  ];

  endpoints.forEach(endpoint => {
    it(`${endpoint} returns 200 with valid shape`, async () => {
      const res = await request(app)
        .get(endpoint)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
    });
  });

  it('overview returns required fields', async () => {
    const res = await request(app)
      .get('/api/analytics/overview')
      .set('Authorization', `Bearer ${token}`);
    expect(res.body).toHaveProperty('total_meetings');
    expect(res.body).toHaveProperty('total_tasks');
    expect(res.body).toHaveProperty('completion_rate');
    expect(res.body).toHaveProperty('overdue_tasks');
  });

  it('requires authentication', async () => {
    const res = await request(app).get('/api/analytics/overview');
    expect(res.status).toBe(401);
  });
});

// ── Search ─────────────────────────────────────────────────────────────────
describeIfDB('GET /api/search', () => {
  it('returns empty results for new workspace', async () => {
    const res = await request(app)
      .get('/api/search')
      .query({ q: 'test' })
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('total');
    expect(res.body).toHaveProperty('results');
    expect(res.body.total).toBe(0);
  });

  it('rejects query shorter than 2 chars', async () => {
    const res = await request(app)
      .get('/api/search')
      .query({ q: 'a' })
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(400);
  });

  it('rejects missing query', async () => {
    const res = await request(app)
      .get('/api/search')
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(400);
  });

  it('requires authentication', async () => {
    const res = await request(app).get('/api/search').query({ q: 'test' });
    expect(res.status).toBe(401);
  });
});

// ── Export ─────────────────────────────────────────────────────────────────
describeIfDB('GET /api/export/*', () => {
  it('tasks.csv returns CSV content-type', async () => {
    const res = await request(app)
      .get('/api/export/tasks.csv')
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/text\/csv/);
    expect(res.headers['content-disposition']).toMatch(/attachment/);
  });

  it('tasks.csv contains header row', async () => {
    const res = await request(app)
      .get('/api/export/tasks.csv')
      .set('Authorization', `Bearer ${token}`);
    expect(res.text).toContain('title');
    expect(res.text).toContain('assignee_name');
    expect(res.text).toContain('priority');
  });

  it('requires authentication', async () => {
    const res = await request(app).get('/api/export/tasks.csv');
    expect(res.status).toBe(401);
  });
});

// ── Health ─────────────────────────────────────────────────────────────────
describe('GET /api/health', () => {
  it('liveness check returns 200', async () => {
    if (!app) return;
    const { createApp } = require('../../src/testApp');
    const testApp = createApp();
    const res = await request(testApp).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});
