/**
 * API Integration Tests — Auth
 *
 * Tests the full HTTP request/response cycle for auth endpoints.
 * Uses supertest to spin up the Express app without binding a port.
 *
 * Requires a test database. Set TEST_DATABASE_URL in .env.test
 * or the tests will be skipped if no DB is available.
 */

const request = require('supertest');

// Use test DB if available, otherwise skip
const DB_AVAILABLE = !!process.env.TEST_DATABASE_URL || !!process.env.DATABASE_URL;

// Conditionally skip if no DB
const describeIfDB = DB_AVAILABLE ? describe : describe.skip;

let app;

beforeAll(async () => {
  if (!DB_AVAILABLE) return;
  // Set test env
  process.env.NODE_ENV = 'test';
  process.env.JWT_SECRET = 'test-secret-at-least-32-chars-long!!';
  process.env.REDIS_URL = process.env.TEST_REDIS_URL || 'redis://localhost:6379';

  // Import app after env is set
  const { createApp } = require('../../src/testApp');
  app = createApp();
});

describeIfDB('POST /api/auth/register', () => {
  const unique = Date.now();

  it('creates a workspace and user', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test User',
        email: `test${unique}@example.com`,
        password: 'password123',
        workspaceName: `Test Workspace ${unique}`,
      });

    expect(res.status).toBe(201);
    expect(res.body.user.email).toBe(`test${unique}@example.com`);
    expect(res.body.accessToken).toBeTruthy();
    expect(res.body.refreshToken).toBeTruthy();
    expect(res.body.user.password_hash).toBeUndefined(); // never expose hash
  });

  it('rejects duplicate email', async () => {
    const email = `dup${unique}@example.com`;
    await request(app).post('/api/auth/register').send({
      name: 'User 1', email, password: 'password123', workspaceName: `WS ${unique}a`,
    });

    const res = await request(app).post('/api/auth/register').send({
      name: 'User 2', email, password: 'password456', workspaceName: `WS ${unique}b`,
    });

    expect(res.status).toBe(409);
    expect(res.body.error).toMatch(/already registered/i);
  });

  it('rejects short password', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'User', email: `short${unique}@ex.com`, password: '123', workspaceName: 'WS',
    });
    expect(res.status).toBe(400);
  });

  it('rejects missing fields', async () => {
    const res = await request(app).post('/api/auth/register').send({ name: 'User' });
    expect(res.status).toBe(400);
  });
});

describeIfDB('POST /api/auth/login', () => {
  const unique = Date.now() + 1;
  const creds = { email: `login${unique}@example.com`, password: 'testpassword123' };

  beforeAll(async () => {
    await request(app).post('/api/auth/register').send({
      name: 'Login Tester', ...creds, workspaceName: `Login WS ${unique}`,
    });
  });

  it('returns tokens on valid credentials', async () => {
    const res = await request(app).post('/api/auth/login').send(creds);
    expect(res.status).toBe(200);
    expect(res.body.accessToken).toBeTruthy();
    expect(res.body.user.email).toBe(creds.email);
  });

  it('rejects wrong password', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: creds.email, password: 'wrongpassword',
    });
    expect(res.status).toBe(401);
  });

  it('rejects unknown email', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: 'nobody@nowhere.com', password: 'anypassword',
    });
    expect(res.status).toBe(401);
  });
});

describeIfDB('GET /api/auth/me', () => {
  const unique = Date.now() + 2;
  let token;

  beforeAll(async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Me Tester', email: `me${unique}@example.com`,
      password: 'password123', workspaceName: `Me WS ${unique}`,
    });
    token = res.body.accessToken;
  });

  it('returns current user with valid token', async () => {
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.email).toBe(`me${unique}@example.com`);
    expect(res.body.password_hash).toBeUndefined();
  });

  it('returns 401 without token', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.status).toBe(401);
  });

  it('returns 401 with invalid token', async () => {
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', 'Bearer invalidtoken123');
    expect(res.status).toBe(401);
  });
});
