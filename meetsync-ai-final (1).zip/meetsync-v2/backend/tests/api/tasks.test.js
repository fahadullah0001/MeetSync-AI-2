/**
 * API Integration Tests — Tasks
 */

const request = require('supertest');

const DB_AVAILABLE = !!process.env.TEST_DATABASE_URL || !!process.env.DATABASE_URL;
const describeIfDB = DB_AVAILABLE ? describe : describe.skip;

let app, token, workspaceId;

beforeAll(async () => {
  if (!DB_AVAILABLE) return;
  process.env.NODE_ENV = 'test';
  process.env.JWT_SECRET = 'test-secret-at-least-32-chars-long!!';

  const { createApp } = require('../../src/testApp');
  app = createApp();

  // Register a test user
  const unique = Date.now();
  const res = await request(app).post('/api/auth/register').send({
    name: 'Task Tester', email: `tasks${unique}@example.com`,
    password: 'password123', workspaceName: `Tasks WS ${unique}`,
  });
  token = res.body.accessToken;
  workspaceId = res.body.workspace.id;
});

describeIfDB('GET /api/tasks', () => {
  it('returns empty array for new workspace', async () => {
    const res = await request(app)
      .get('/api/tasks')
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it('requires authentication', async () => {
    const res = await request(app).get('/api/tasks');
    expect(res.status).toBe(401);
  });
});

describeIfDB('GET /api/tasks/stats/summary', () => {
  it('returns stats object', async () => {
    const res = await request(app)
      .get('/api/tasks/stats/summary')
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('total');
    expect(res.body).toHaveProperty('done');
    expect(res.body).toHaveProperty('overdue');
    expect(res.body).toHaveProperty('completion_rate');
  });
});
