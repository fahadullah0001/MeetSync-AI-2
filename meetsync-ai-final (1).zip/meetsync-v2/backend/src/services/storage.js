/**
 * AWS S3 service for audio file storage
 */

const { S3Client, PutObjectCommand, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const fs = require('fs');
const path = require('path');

const s3 = new S3Client({
  region: process.env.AWS_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const BUCKET = process.env.AWS_S3_BUCKET || 'meetsync-audio';

/**
 * Upload an audio file to S3
 * Returns the S3 key
 */
async function uploadAudio(localPath, meetingId) {
  const ext = path.extname(localPath);
  const key = `meetings/${meetingId}/audio${ext}`;

  const fileStream = fs.createReadStream(localPath);
  const contentType = getContentType(ext);

  await s3.send(new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    Body: fileStream,
    ContentType: contentType,
  }));

  return `s3://${BUCKET}/${key}`;
}

/**
 * Get a pre-signed URL for a file (valid 1 hour)
 */
async function getPresignedUrl(s3Url, expiresInSeconds = 3600) {
  const key = s3Url.replace(`s3://${BUCKET}/`, '');
  const command = new GetObjectCommand({ Bucket: BUCKET, Key: key });
  return getSignedUrl(s3, command, { expiresIn: expiresInSeconds });
}

function getContentType(ext) {
  const map = {
    '.mp4': 'video/mp4',
    '.mp3': 'audio/mpeg',
    '.m4a': 'audio/mp4',
    '.wav': 'audio/wav',
    '.ogg': 'audio/ogg',
    '.webm': 'audio/webm',
  };
  return map[ext.toLowerCase()] || 'application/octet-stream';
}

module.exports = { uploadAudio, getPresignedUrl };
