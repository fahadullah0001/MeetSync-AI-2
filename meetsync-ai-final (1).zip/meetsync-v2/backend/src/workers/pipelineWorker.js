/**
 * Pipeline Worker
 *
 * Runs as a SEPARATE process: npm run worker
 * Pulls jobs off the 'meeting-pipeline' Redis queue.
 * Decoupled from the API server — scale independently.
 *
 * Usage:
 *   npm run worker           # run one worker
 *   WORKER_CONCURRENCY=5 npm run worker   # run 5 concurrent workers
 */

require('dotenv').config();
const { Worker } = require('bullmq');
const IORedis = require('ioredis');
const { processMeeting } = require('../services/aiPipeline');

const connection = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379', {
  maxRetriesPerRequest: null,
});

const concurrency = parseInt(process.env.WORKER_CONCURRENCY || '2', 10);

const worker = new Worker(
  'meeting-pipeline',
  async (job) => {
    console.log(`[Worker] Processing job ${job.id} — meetingId: ${job.data.meetingId}`);

    const { meetingId, localPath } = job.data;

    // Report progress back to the queue (visible in Bull Board dashboard)
    await job.updateProgress(5);

    await processMeeting(meetingId, localPath, async (step, pct) => {
      await job.updateProgress(pct);
      console.log(`[Worker] ${meetingId} — ${step} (${pct}%)`);
    });

    return { success: true, meetingId };
  },
  {
    connection,
    concurrency,
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
  }
);

worker.on('completed', (job, result) => {
  console.log(`[Worker] Job ${job.id} completed — meeting ${result.meetingId}`);
});

worker.on('failed', (job, err) => {
  console.error(`[Worker] Job ${job?.id} failed:`, err.message);
});

worker.on('error', (err) => {
  console.error('[Worker] Error:', err);
});

console.log(`MeetSync Pipeline Worker started — concurrency: ${concurrency}`);
console.log('Waiting for jobs on queue: meeting-pipeline...');

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Shutting down worker...');
  await worker.close();
  process.exit(0);
});
